WEBSITE CHÀO ĐÓN TÂN SINH VIÊN K26 – VOV COLLEGE

Cách xuất bản bằng GitHub Pages:
1. Đăng nhập GitHub và mở repository của bạn.
2. Vào Add file > Upload files.
3. Giải nén file ZIP này trên laptop.
4. Tải lên index.html và toàn bộ thư mục assets (giữ nguyên cấu trúc).
5. Nhấn Commit changes.
6. Vào Settings > Pages.
7. Chọn Deploy from a branch, Branch: main, Folder: /(root), rồi Save.
8. Đợi GitHub Pages xuất bản và nhấn Visit site.

Lưu ý: index.html phải nằm ở thư mục gốc của repository; thư mục assets phải nằm cùng cấp với index.html.
